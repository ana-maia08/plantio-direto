let campo;
let sementes = ['milho', 'soja', 'feijao'];
let sementeSelecionada = 'milho';
let pontos = 0;
let turno = 0;
let clima = 'normal'; // Pode ser 'normal', 'seca', 'chuva'

function setup() {
  createCanvas(600, 600);
  campo = new Campo(10, 10, 60); // Campo com 10x10 células e cada célula de 60px
  textSize(18);
  textAlign(CENTER, CENTER);
  frameRate(1); // Definindo um frame rate mais baixo para representar turnos
}

function draw() {
  background(200, 220, 255);
  
  // Exibe o campo e o estado das plantas
  campo.display();
  
  // Exibe informações sobre o clima, pontos e turno
  fill(0);
  text('Pontos: ' + pontos, width / 2, 20);
  text('Turno: ' + turno, width / 2, 40);
  text('Clima: ' + clima, width / 2, 60);
  text('Plantando: ' + sementeSelecionada, width / 2, height - 20);

  // Aciona o ciclo de clima e crescimento a cada turno
  if (turno % 5 === 0) {
    mudarClima();
  }
  
  // Ciclo de crescimento das plantas
  if (turno > 0 && turno % 2 === 0) {
    campo.crescerPlantas();
  }
}

function mousePressed() {
  let col = floor(mouseX / campo.tamanho);
  let row = floor(mouseY / campo.tamanho);
  
  if (col < campo.colunas && row < campo.linhas) {
    campo.plantarSemente(row, col, sementeSelecionada);
  }
}

function keyPressed() {
  // Troca de semente com as teclas
  if (key === '1') {
    sementeSelecionada = 'milho';
  } else if (key === '2') {
    sementeSelecionada = 'soja';
  } else if (key === '3') {
    sementeSelecionada = 'feijao';
  }
}

function mudarClima() {
  let rand = floor(random(3));
  if (rand === 0) {
    clima = 'normal';
  } else if (rand === 1) {
    clima = 'seca';
  } else {
    clima = 'chuva';
  }
  console.log('Clima mudou para: ' + clima);
}

class Campo {
  constructor(linhas, colunas, tamanho) {
    this.linhas = linhas;
    this.colunas = colunas;
    this.tamanho = tamanho;
    this.campo = Array(linhas).fill().map(() => Array(colunas).fill(null));
    this.statusSolo = Array(linhas).fill().map(() => Array(colunas).fill('normal')); // Solo pode ser 'normal', 'pobre' ou 'rico'
  }
  
  display() {
    for (let i = 0; i < this.linhas; i++) {
      for (let j = 0; j < this.colunas; j++) {
        let x = j * this.tamanho;
        let y = i * this.tamanho;
        
        // Exibe o solo com base no estado
        if (this.statusSolo[i][j] === 'normal') {
          fill(150, 111, 51); // Solo normal
        } else if (this.statusSolo[i][j] === 'rico') {
          fill(107, 142, 35); // Solo rico
        } else {
          fill(169, 105, 38); // Solo pobre
        }
        stroke(0);
        rect(x, y, this.tamanho, this.tamanho);
        
        // Exibe as sementes plantadas e o ciclo de crescimento
        if (this.campo[i][j]) {
          textSize(24);
          fill(0);
          text(this.campo[i][j].substring(0, 1).toUpperCase(), x + this.tamanho / 2, y + this.tamanho / 2);
          
          // Exibe o status da planta
          let planta = this.campo[i][j];
          if (planta === 'milho') {
            text('🌽', x + this.tamanho / 2, y + this.tamanho / 2);
          } else if (planta === 'soja') {
            text('🌱', x + this.tamanho / 2, y + this.tamanho / 2);
          } else if (planta === 'feijao') {
            text('🌿', x + this.tamanho / 2, y + this.tamanho / 2);
          }
        }
      }
    }
  }
  
  plantarSemente(linha, coluna, semente) {
    if (!this.campo[linha][coluna]) {
      // Verifica a rotação de culturas
      let soloAtual = this.statusSolo[linha][coluna];
      
      // Se a semente foi plantada anteriormente na célula, aplica penalidade
      if (this.campo[linha][coluna] === semente) {
        this.statusSolo[linha][coluna] = 'pobre';
        pontos -= 5; // Penalidade por repetição
      } else {
        this.campo[linha][coluna] = semente;
        this.statusSolo[linha][coluna] = 'rico'; // Solo fica mais fértil
        pontos += 10; // Aumento de pontos por plantio bem-sucedido
      }
    }
  }
  
  crescerPlantas() {
    // O clima afeta o crescimento das plantas
    for (let i = 0; i < this.linhas; i++) {
      for (let j = 0; j < this.colunas; j++) {
        if (this.campo[i][j]) {
          // Crescimento afetado pelo clima
          if (clima === 'seca') {
            this.statusSolo[i][j] = 'pobre'; // Solo empobrece com seca
            pontos -= 5; // Penalidade por seca
          } else if (clima === 'chuva') {
            this.statusSolo[i][j] = 'rico'; // Solo melhora com chuva
            pontos += 5; // Bonus por boas condições climáticas
          }
        }
      }
    }
  }
}